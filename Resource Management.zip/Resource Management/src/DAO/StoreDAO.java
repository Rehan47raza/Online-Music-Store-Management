package DAO;

import java.io.IOException;
import java.io.InputStream;
import java.sql.*;

import javax.servlet.http.Part;

import bean.Store;

public class StoreDAO 
{
	public Connection getConnection() throws SQLException
	{
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		}
		Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@INGNRGPILPHP01:1521:ORCLILP", "aja185core", "aja185core");
		return connection;
	}
	
	public int insertData(Store s,Part filePart,Part doc) throws SQLException, IOException
	{
		Connection c=getConnection();
		PreparedStatement st=c.prepareStatement("insert into mytunes values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
		st.setInt(1, s.getSongId());
		st.setString(2, s.getTitle());
		st.setString(3, s.getArtist());
		st.setString(4, s.getDirector());
		st.setString(5, s.getLang());
		st.setString(6,s.getType());
		st.setString(7, s.getGenre());
		st.setString(8, s.getAvail());
		st.setString(9, s.getFormat());
		st.setDouble(10,s.getPrice());
		st.setInt(11, s.getDiscount());
		st.setString(13, s.getTracks());
		st.setString(14, s.getOther());
		st.setString(15, s.getAwards());
		InputStream inputStream=null;
		if(filePart != null) 
		{
            // prints out some information for debugging
            System.out.println(filePart.getName());
            System.out.println(filePart.getSize());
            System.out.println(filePart.getContentType());
             
            // obtains input stream of the upload file
           inputStream = filePart.getInputStream();
        }
		st.setBlob(12, inputStream);
		InputStream docInputStream = null;
		if(doc != null) 
		{
            // prints out some information for debugging
            System.out.println(doc.getName());
            System.out.println(doc.getSize());
            System.out.println(doc.getContentType());
             
            // obtains input stream of the upload file
           docInputStream = filePart.getInputStream();
        }
		st.setBlob(16, docInputStream);
		int i = st.executeUpdate();
		return i;
	}
	
	
}  