package Controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import bean.Store;

import DAO.StoreDAO;

/**
 * Servlet implementation class StoreController
 */
@WebServlet("/StoreController")
public class StoreController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StoreController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		Part filePart = request.getPart("photo");
		Part doc=request.getPart("doc");
		StoreDAO str=new StoreDAO();
		Store s=new Store();
		s.setSongId(Integer.parseInt(request.getParameter("id")));
		s.setTitle(request.getParameter("title"));
		s.setArtist(request.getParameter("artist"));
		s.setDirector(request.getParameter("director"));
		s.setLang(request.getParameter("language"));
		s.setType(request.getParameter("radiotype"));
		s.setGenre(request.getParameter("genre"));
		s.setAvail(request.getParameter("avail"));
		s.setFormat(request.getParameter("format"));
		s.setPrice(Double.parseDouble(request.getParameter("price")));
		s.setDiscount(Integer.parseInt(request.getParameter("discount")));
		try {
			int i=str.insertData(s, filePart, doc);
			System.out.println(i);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
