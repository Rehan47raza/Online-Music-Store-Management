package com.DAO;

import java.io.IOException;
import java.io.InputStream;
import java.sql.*;
import java.util.ArrayList;

import javax.servlet.http.Part;

import com.bean.Store;


public class StoreDAO 
{
	public Connection getConnection() throws SQLException
	{
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		}
		Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@INGNRGPILPHP01:1521:ORCLILP", "aja185core", "aja185core");
		return connection;
	}
	
	public int insertData(Store s) throws  IOException
	{
		Connection c;
		int i=0;
		try {
			c = getConnection();
		
		PreparedStatement st=c.prepareStatement("insert into mytunes values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
		st.setInt(1, s.getSongId());
		st.setString(2, s.getTitle());
		st.setString(3, s.getArtist());
		st.setString(4, s.getDirector());
		st.setString(5, s.getLang());
		st.setString(6,s.getType());
		st.setString(7, s.getGenre());
		st.setString(8, s.getAvail());
		st.setString(9, s.getFormat());
		st.setDouble(10,s.getPrice());
		st.setInt(11, s.getDiscount());
		st.setString(13, s.getTracks());
		st.setString(14, s.getOther());
		st.setString(15, s.getAwards());
		InputStream inputStream=null;
		if(s.getImg() != null) 
		{
           inputStream = s.getImg().getInputStream();
        }
		st.setBlob(12, inputStream);
		InputStream docInputStream = null;
		if(s.getDoc() != null) 
		{
           docInputStream = s.getDoc().getInputStream();
        }
		st.setBlob(16, docInputStream);
		i = st.executeUpdate();
		} catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}
	
	public ArrayList<Store> getData() throws SQLException
	{
		ArrayList<Store> as=new ArrayList<Store>();
		Connection c=getConnection();
		PreparedStatement st=c.prepareStatement("select * from mytunes order by song_id");
		ResultSet rs=st.executeQuery();
		while(rs.next())
		{
			Store s=new Store();
			s.setSongId(rs.getInt(1));
			s.setTitle(rs.getString(2));
			s.setArtist(rs.getString(3));
			s.setDirector(rs.getString(4));
			s.setLang(rs.getString(5));
			s.setType(rs.getString(6));
			s.setGenre(rs.getString(7));
			s.setAvail(rs.getString(8));
			s.setFormat(rs.getString(9));
			s.setPrice(rs.getDouble(10));
			s.setDiscount(rs.getInt(11));
			s.setImg((Part) rs.getBlob(12));
			s.setTracks(rs.getString(13));
			s.setOther(rs.getString(14));
			s.setAwards(rs.getString(15));
			s.setDoc((Part) rs.getBlob(16));
			as.add(s);
		}
		return as;
	}
	public Blob getImage() throws SQLException
	{
		Connection c=getConnection();
		PreparedStatement st=c.prepareStatement("select cover_image from mytunes");
		ResultSet rs=st.executeQuery();
		Blob b=null;
		while(rs.next())
		{
			b=rs.getBlob(1);
		}
		return b;
	}
	
	public Store getRecordById(int id)
	{  
		Store s=null;
		try
		{  
			Connection con=getConnection();  
			PreparedStatement ps=con.prepareStatement("select * from mytunes where song_id=?");  
			ps.setInt(1,id);  
			ResultSet rs=ps.executeQuery();
			
			while(rs.next())
			{  
				s=new Store();
				s.setSongId(rs.getInt(1));
				s.setTitle(rs.getString(2));
				s.setArtist(rs.getString(3));
				s.setDirector(rs.getString(4));
				s.setLang(rs.getString(5));
				s.setType(rs.getString(6));
				s.setGenre(rs.getString(7));
				s.setAvail(rs.getString(8));
				s.setFormat(rs.getString(9));
				s.setPrice(rs.getDouble(10));
				s.setDiscount(rs.getInt(11));
				s.setImg((Part) rs.getBlob(12));
				s.setTracks(rs.getString(13));
				s.setOther(rs.getString(14));
				s.setAwards(rs.getString(15));
				s.setDoc((Part) rs.getBlob(16));
			}  
		}
		catch(Exception e)
		{
			e.getStackTrace();
		}  
		return s;  
	} 
	
	public int update(Store u)
	{  
		int status=0;  
		try
		{  
			Connection con=getConnection();  
			PreparedStatement ps=con.prepareStatement("update mytunes set title=?,artiste=?,music_director=?,language=?,music_type=?,genre=?,availibility=?,format=?,online_price=?,discount=?,cover_image=?,track_listing=?,other_specifications=?,awards_if_any=?,sample_contents_upload=? where song_id=?");  
			ps.setString(1,u.getTitle());  
			ps.setString(2,u.getArtist());  
			ps.setString(3,u.getDirector());  
			ps.setString(4,u.getLang());  
			ps.setString(5,u.getType());
			ps.setString(6,u.getGenre());
			ps.setString(7,u.getAvail());
			ps.setString(8,u.getFormat());
			ps.setDouble(9,u.getPrice());
			ps.setInt(10, u.getDiscount());
			ps.setBlob(11,(Blob) u.getImg());
			ps.setString(12,u.getTracks());
			ps.setString(13,u.getOther());
			ps.setString(14,u.getAwards());
			ps.setBlob(15,(Blob) u.getDoc());
			ps.setInt(16,u.getSongId());  
			status=ps.executeUpdate(); 
			System.out.println(status);
		}
		catch(Exception e){System.out.println(e);}  
			return status;  
	}  
	public ArrayList<Integer> getId() throws SQLException
	{
		ArrayList<Integer> id=new ArrayList<Integer>();
		Connection con=getConnection();  
		PreparedStatement ps=con.prepareStatement("select Song_Id from mytunes");  
		ResultSet rs=ps.executeQuery();
		while(rs.next())
		{
			int i=rs.getInt(1);
			id.add(i);
		}
		return id;
	}
	public int delete(int u)
	{  
		int status=0;  
		try
		{  
			Connection con=getConnection();  
			PreparedStatement ps=con.prepareStatement("delete from mytunes where song_id=?");  
			ps.setInt(1,u);  
			status=ps.executeUpdate();  
		}
		catch(Exception e)
		{
			System.out.println(e);
		}  
		return status;  
	}
}  