package com.DAO;

import java.sql.*;

public class LoginDAO 
{
	public Connection getConnection() throws SQLException
	{
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
		}
		Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@INGNRGPILPHP01:1521:ORCLILP", "aja185core", "aja185core");
		return connection;
	}
	
	public String getUser(String name) throws SQLException
	{
		String password = null;
		Connection cn=getConnection();
		Statement st=cn.createStatement();
		ResultSet rs=st.executeQuery("select password from tbl_store_admin where username='"+name+"'");
		while(rs.next())
		{
			password=rs.getString(1);
		}
		return password;
	}
}