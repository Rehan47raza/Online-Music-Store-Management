package com.Controller;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.DAO.StoreDAO;
import com.bean.Store;

/**
 * Servlet implementation class ShowMusic
 */
@WebServlet("/UpdateController")
public class UpdateController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		/*int i=0;
		StoreDAO s=new StoreDAO();
		
		try 
		{
			Blob b = s.getImage();
			byte barr[]=b.getBytes(0,(int)b.length());//1 means first image  
            
			FileOutputStream fout=new FileOutputStream("C://Users/1122308/Pictures/abc"+i+".jpg");  
			fout.write(barr);  
			i++;              
			fout.close(); 
		} 
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		StoreDAO sd=new StoreDAO();
		HttpSession ss=request.getSession();
		int id=Integer.parseInt(request.getParameter("Songid"));
		System.out.println(request.getParameter("Songid"));
		Store s=sd.getRecordById(id);
		ss.setAttribute("store",s);
		response.sendRedirect("editform.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		StoreDAO sd=new StoreDAO();
		HttpSession ss=request.getSession();
		int id=Integer.parseInt(request.getParameter("id"));
		Store s=new Store();
		s.setSongId(id);
		s.setTitle(request.getParameter("name"));
		s.setArtist(request.getParameter("artist"));
		s.setDirector(request.getParameter("director"));
		s.setAvail(request.getParameter("avail"));
		s.setFormat(request.getParameter("format"));
		s.setLang(request.getParameter("language"));
		s.setType(request.getParameter("music_type"));
		s.setGenre(request.getParameter("genre"));
		s.setPrice(Double.parseDouble(request.getParameter("price")));
		s.setDiscount(Integer.parseInt(request.getParameter("discount")));
		s.setTracks(request.getParameter("track"));
		s.setAwards(request.getParameter("awards"));
		s.setOther(request.getParameter("others"));
		s.setImg(request.getPart("image"));
		s.setDoc(request.getPart("doc"));
		
		ss.setAttribute("store",s);
        sd.update(s);
        response.sendRedirect("ViewMusic.jsp");
	}
}
