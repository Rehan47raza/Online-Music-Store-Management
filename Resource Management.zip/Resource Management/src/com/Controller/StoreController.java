package com.Controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import com.DAO.StoreDAO;
import com.bean.Store;



/**
 * Servlet implementation class StoreController
 */
@WebServlet("/StoreController")
public class StoreController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StoreController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		/*StoreDAO sd=new StoreDAO();
		try 
		{
			ArrayList<Store> as=sd.getData();
			HttpSession ss=request.getSession();
			ss.setAttribute("musicList", as);
			response.sendRedirect("ViewMusic.jsp");
		} 
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		Part filePart = request.getPart("image");
		Part doc=request.getPart("doc");
		StoreDAO str=new StoreDAO();
		Store s=new Store();
		s.setSongId(Integer.parseInt(request.getParameter("id")));
		s.setTitle(request.getParameter("title"));
		s.setArtist(request.getParameter("artist"));
		s.setDirector(request.getParameter("director"));
		s.setLang(request.getParameter("language"));
		s.setType(request.getParameter("music_type"));
		s.setGenre(request.getParameter("genre"));
		s.setAvail(request.getParameter("radiotype"));
		s.setFormat(request.getParameter("format"));
		s.setPrice(Double.parseDouble(request.getParameter("price")));
		s.setDiscount(Integer.parseInt(request.getParameter("discount")));
		s.setTracks(request.getParameter("track"));
		s.setAwards(request.getParameter("awards"));
		s.setOther(request.getParameter("others"));
		s.setImg(filePart);
		s.setDoc(doc);
		int j=0;
		j=str.insertData(s);
		response.sendRedirect("ViewMusic.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		try 
		{
			StoreDAO sd=new StoreDAO();
			ArrayList<Store> as=sd.getData();
			HttpSession ss=request.getSession();
			ss.setAttribute("musicList", as);
			response.sendRedirect("ViewMusic.jsp");
		} 
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
